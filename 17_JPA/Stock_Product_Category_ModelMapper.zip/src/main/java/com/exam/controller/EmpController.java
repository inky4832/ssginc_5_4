package com.exam.controller;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.exam.dto.CategoryDTO;
import com.exam.dto.ProductDTO;
import com.exam.dto.StockDTO;
import com.exam.service.EmpService;



@RestController
public class EmpController {

	@Autowired
	EmpService service;
	
	
	@GetMapping("/findAll")
	public List<StockDTO> findAll(){
		return service.findAll();
	}
	
	@PostMapping("/stock")
	public void stockSave(@RequestBody StockDTO dto) {
		service.stockSave(dto);
	}
	
	@PostMapping("/product")
	public void productSave(@RequestBody ProductDTO dto) {
		service.productSave(dto);
	}
	
	@PostMapping("/category")
	public void categorySave(@RequestBody CategoryDTO dto) {
		service.categorySave(dto);
	}
	
//	// 1. 조회 ( Select )
//	@GetMapping("/findByEname/{name}")
//	public List<EmpDTO> findByEname(@PathVariable String name){
//		return service.findByEname(name);
//	}
//
//	@GetMapping("/findByJobOrderBySalDesc/{job}")
//	public List<EmpDTO> findByJobOrderBySalDesc(@PathVariable String job){
//		return service.findByJobOrderBySalDesc(job);
//	}
//	
//	@GetMapping("/findByJobAndSal/{job}/{sal}")
//	public List<EmpDTO> findByJobAndSal(@PathVariable String job, @PathVariable long sal){
//		return service.findByJobAndSal(job, sal);
//	}
//	
//	@GetMapping("/findByEmpnoIn")
//	public List<EmpDTO> findByEmpnoIn(){
//		List<Long> empnoList = Arrays.asList(7369L,7499L, 7521L);
//		return service.findByEmpnoIn(empnoList);
//	}
//	
//	@GetMapping("/findBySalLessThan/{sal}")
//	public List<EmpDTO> findBySalLessThan(@PathVariable long sal){
//		return service.findBySalLessThan(sal);
//	}
//	
//
//	@GetMapping("/findBySalBetween/{lowsal}/{hisal}")
//	public List<EmpDTO> findBySalBetween(@PathVariable long lowsal,  @PathVariable long hisal ){
//		return service.findBySalBetween(lowsal, hisal);
//	}
//	// Containing: 양쪽에 % 추가됨.  예> %LA%
//	@GetMapping("/findByEnameContaining/{ename}")
//	public List<EmpDTO> findByEnameContaining(@PathVariable String ename){
//		return service.findByEnameContaining(ename);
//	}
//	// EndingWith: 앞쪽에 % 추가됨.  예> %LA
//	@GetMapping("/findByEnameEndingWith/{ename}")
//	public List<EmpDTO> findByEnameEndingWith(@PathVariable String ename){
//		return service.findByEnameEndingWith(ename);
//	}
//	// StartingWith: 뒤쪽에 % 추가됨.  예> LA%
//	@GetMapping("/findByEnameStartingWith/{ename}")
//	public List<EmpDTO> findByEnameStartingWith(@PathVariable String ename){
//		return service.findByEnameStartingWith(ename);
//	}
//	
//	@GetMapping("/findByCommIsNull")
//	public List<EmpDTO> findByCommIsNull(){
//		return service.findByCommIsNull();
//	}
//	
//	@GetMapping("/deleteByEmpno/{empno}")
//	public void deleteByEmpno(@PathVariable long empno){
//		 service.deleteByEmpno(empno);
//	}
//	
//	@GetMapping("/countByJob/{job}")
//	public long countByJob(@PathVariable String job){
//		 return service.countByJob(job);
//	}

}





package com.exam.service;

import java.util.List;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exam.dto.CategoryDTO;
import com.exam.dto.ProductDTO;
import com.exam.dto.StockDTO;
import com.exam.entity.Category;
import com.exam.entity.Product;
import com.exam.entity.Stock;
import com.exam.repository.CategoryRepository;
import com.exam.repository.ProductRepository;
import com.exam.repository.StockRepository;

@Service
@Transactional
public class EmpServiceImpl implements EmpService{

	@Autowired
	StockRepository stockRepository;
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	CategoryRepository categoryRepository;
	
	@Autowired
	ModelMapper mapper;
	
	@Override
	public List<StockDTO> findAll(){
		
		
		List<Stock> empList = stockRepository.findAll();
		System.out.println("StockList>>>>" + empList);
		List<StockDTO> list = 
				empList.stream().map(emp -> mapper.map(emp, StockDTO.class)).collect(Collectors.toList());
		
		return list;
	}

	@Override
	public void stockSave(StockDTO dto) {
		Stock stock = mapper.map(dto, Stock.class);
		 stockRepository.save(stock);
	}

	@Override
	public void productSave(ProductDTO dto) {
		Product p = mapper.map(dto, Product.class);
		productRepository.save(p);
	}

	@Override
	public void categorySave(CategoryDTO dto) {
		Category c = mapper.map(dto, Category.class);
		categoryRepository.save(c);
	}
	
	
	
	
	
	
//	
//	//유틸리티 메서드
//		public Emp fromEmpDTOToEmp(EmpDTO dto) {
//			System.out.println("EmpDTO >>>>>>>>>>>>>>>>>>>>>>>" + dto);
//			Emp entity = Emp.builder()
//	                .empno(dto.getEmpno())
//	                .ename(dto.getEname())
//	                .sal(dto.getSal())
//	                 .build();
//			System.out.println("Emp >>>>>>>>>>>>>>>>>>>>>>>" + entity);
//			return entity;
//		}
//		public EmpDTO fromEmpToEmpDTO(Emp entity) {
//			EmpDTO dto = EmpDTO.builder()
//	                .empno(entity.getEmpno())
//	                .ename(entity.getEname())
//	                .job(entity.getJob())
//	                .mgr(entity.getMgr())
//	                .hiredate(entity.getHiredate())
//	                .comm(entity.getComm())
//	                .sal(entity.getSal())
//	                .build();
//			return dto;
//		}
//		private List<EmpDTO> fromEmpListToEmpDTOList(List<Emp> entity) {
//			List<EmpDTO> list = 
//					entity.stream().map( emp -> EmpDTO.builder()
//							                   .empno(emp.getEmpno())
//							                   .ename(emp.getEname())
//							                   .job(emp.getJob())
//							                   .mgr(emp.getMgr())
//							                   .hiredate(emp.getHiredate())
//							                   .comm(emp.getComm())
//							                   .sal(emp.getSal())
//							                   .dept(null)
//							                    .build()
//							                    ).collect(Collectors.toList());
//			
//			return list;
//		}
//
//		private List<Emp> fromEmpDTOListToEmpList(List<EmpDTO> dto) {
//			List<Emp> list = 
//					dto.stream().map( x -> Emp.builder()
//							                   .empno(x.getEmpno())
//							                   .ename(x.getEname())
//							                   .sal(x.getSal())
//							                    .build()
//							                    ).collect(Collectors.toList());
//			
//			return list;
//		}
//	
//	@Override
//	public List<EmpDTO> findByEname(String ename) {
//		List<Emp> entity = repository.findByEname(ename);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;
//	}
//
//	@Override
//	public List<EmpDTO> findByJobOrderBySalDesc(String job) {
//		List<Emp> entity = repository.findByJobOrderBySalDesc(job);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;
//	}
//	
//	@Override
//	public List<EmpDTO> findByJobAndSal(String job, long sal) {
//		List<Emp> entity = repository.findByJobAndSal(job, sal);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;	
//	}
//
//	@Override
//	public List<EmpDTO> findByEmpnoIn(List<Long> empnoList) {
//		List<Emp> entity = repository.findByEmpnoIn(empnoList);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;		
//	}
//
//	@Override
//	public List<EmpDTO> findBySalLessThan(long sal) {
//		List<Emp> entity = repository.findBySalLessThan(sal);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;	
//	}
//
//	@Override
//	public List<EmpDTO> findBySalBetween(long lowsal, long hisal) {
//		List<Emp> entity = repository.findBySalBetween(lowsal, hisal);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;	
//	}
//
//	@Override
//	public List<EmpDTO> findByEnameContaining(String ename) {
//		List<Emp> entity = repository.findByEnameContaining(ename);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;	
//	}
//	@Override
//	public List<EmpDTO> findByEnameEndingWith(String ename) {
//		List<Emp> entity = repository.findByEnameEndingWith(ename);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;	
//	}
//	@Override
//	public List<EmpDTO> findByEnameStartingWith(String ename) {
//		List<Emp> entity = repository.findByEnameStartingWith(ename);
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;	
//	}
//	
//	@Override
//	public List<EmpDTO> findByCommIsNull() {
//		List<Emp> entity = repository.findByCommIsNull();
//		
//		// Emp ----> EmpDTO
//		List<EmpDTO> list = fromEmpListToEmpDTOList(entity);
//		
//		return list;	
//	}
//	
//	@Override
//	public long countByJob(String job) {
//		return repository.countByJob(job);
//	}
//
//	@Override
//	public void deleteByEmpno(long empno) {
//		repository.deleteByEmpno(empno);
//		
//	}


	
	
	

	


}

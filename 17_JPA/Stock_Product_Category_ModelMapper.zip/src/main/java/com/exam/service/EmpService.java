package com.exam.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.exam.dto.CategoryDTO;
import com.exam.dto.ProductDTO;
import com.exam.dto.StockDTO;
import com.exam.entity.Stock;


public interface EmpService {
	
	List<StockDTO> findAll();
	
	void stockSave(StockDTO dto);
	void productSave(ProductDTO dto);
	void categorySave(CategoryDTO dto);

//	List<EmpDTO> findByEname(String ename);
//	List<EmpDTO> findByJobOrderBySalDesc(String job);
//	List<EmpDTO> findByJobAndSal(String job, long sal);
//	List<EmpDTO> findByEmpnoIn(List<Long> empnoList); 
//	List<EmpDTO> findBySalLessThan(long sal); 
//	List<EmpDTO> findBySalBetween(long lowsal, long hisal); 
//	List<EmpDTO> findByEnameContaining(String ename);
//	List<EmpDTO> findByEnameEndingWith(String ename);
//	List<EmpDTO> findByEnameStartingWith(String ename);
//	List<EmpDTO> findByCommIsNull();
//	
//	
//	void deleteByEmpno(long empno);
//	long countByJob(String job);
}

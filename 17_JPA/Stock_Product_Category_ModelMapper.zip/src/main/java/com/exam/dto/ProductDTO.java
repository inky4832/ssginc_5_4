package com.exam.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
@ToString
@Setter
@Getter
public class ProductDTO {
	
	
    private Integer pdIdx;
//    private Integer ctgIdx;
    private UserDTO user;
    private String pdName;
    private Integer pdPrice;
    private Integer pdLimit;
    
    private CategoryDTO category;
    
}
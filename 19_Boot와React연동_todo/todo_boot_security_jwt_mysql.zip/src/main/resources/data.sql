insert into todo ( id, userid, description, targetDate, done ) values ( 1000,'inky4832', 'Learn SpringBoot2.1.8', DATE_ADD(NOW(), INTERVAL 1 YEAR), false);
insert into todo ( id, userid, description, targetDate, done ) values ( 1001,'inky4832', 'Learn Reactjs', DATE_ADD(NOW(), INTERVAL 1 MONTH), false);
insert into todo ( id, userid, description, targetDate, done ) values ( 1002,'inky4832', 'Learn SpringSecurity', DATE_ADD(NOW(), INTERVAL 10 DAY), false);
insert into todo ( id, userid, description, targetDate, done ) values ( 200,'ryu4832', 'Learn Dance', DATE_ADD(NOW(), INTERVAL 3 YEAR), false);




import './HomeComponent.css';


function HomeComponent() {
  return (
<div className="container">
		<div className="back-image">
		
		</div>
	</div>
  );
}

export default HomeComponent;

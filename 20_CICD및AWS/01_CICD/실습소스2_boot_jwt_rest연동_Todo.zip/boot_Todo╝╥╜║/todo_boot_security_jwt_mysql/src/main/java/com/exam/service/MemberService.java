package com.exam.service;

import com.exam.dto.Member;

public interface MemberService {

	
	public Member save(Member member);
}

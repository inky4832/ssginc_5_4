import {useEffect, useState} from 'react';
import UserList  from './UserList.js';
import { fetchEvent, fetchUserSave } from '../http/HttpService.js';
import {
  useQuery,
  useMutation,
  useQueryClient,
  QueryClient,
  QueryClientProvider,
} from '@tanstack/react-query'
import { Link, useNavigate, redirect, Form} from 'react-router-dom';

import { queryClient } from '../http/HttpService';

function UsersAdd(){
///////////////////////////////////////////////////
    return(
        <>
        <h2>UsersAdd</h2>
        <Form method="post">
           id:<input type="text" name="id" /><br/>
           email:<input type="text" name="email"  /><br/>
           first_name:<input type="text" name="first_name" /><br/>
           last_name:<input type="text" name="last_name" /><br/>
           <button>save</button>
        </Form>
     
      </>
    );
}

///////////////////////////////////////
export async function action({request}){
  let formData = await request.formData();

  let id = formData.get("id");
  let email = formData.get("email");
  let first_name = formData.get("first_name");
  let last_name = formData.get("last_name");
  let user ={
    id:id,
    email:email,
    first_name:first_name,
    last_name:last_name
 };

 // 직접 fetchUserSave 메서드 호출
 await fetchUserSave(user);

 // 저장/수정시 변경사항 반영
 await queryClient.invalidateQueries(
  {
    queryKey: ['todos']
  });

 // 리다이렉트
  return redirect("/users");
}

////////////////////////////////////////
export default UsersAdd;
import logo from './logo.svg';
import './App.css';

import { createBrowserRouter, RouterProvider} from 'react-router-dom';
import Home from './pages/Home';
import Products from './pages/Products';
import RootLayout from './pages/RootLayout';
import ErrorPage from './pages/ErrorPage';

import {
  useQuery,
  useMutation,
  useQueryClient,
  QueryClient,
  QueryClientProvider,
} from '@tanstack/react-query'
import UsersSearch from './pages/UsersSearch';

import { queryClient } from './http/HttpService';
import Users, {loader as UserLoader} from './pages/Users';

import UsersAdd, {action as UserAddAction} from './pages/UsersAdd';
const router = createBrowserRouter([
  {
    path:"/",
    element: <RootLayout />,
    errorElement:<ErrorPage />,
    children:[
      {
        path:"/",
        element:<Home />
      },
      {
        path:"/products",
        element:<Products />
      },
      {
        path:"/users",
        element:<Users />,
        loader:UserLoader
      },
      {
        path:"/usersSearch",
        element:<UsersSearch />
      },
      {
        path:"/usersAdd",
        element:<UsersAdd />,
        action:UserAddAction
      }
    ]
  }
]);

// Create a client
// const queryClient = new QueryClient()

function App() {
  return (
    <QueryClientProvider client={queryClient}>
       <RouterProvider router={router} />
    </QueryClientProvider>
  );
}




export default App;



function Products(){
    return(
        <>
        <h2>Products</h2>
      </>
    );
}

export default Products;